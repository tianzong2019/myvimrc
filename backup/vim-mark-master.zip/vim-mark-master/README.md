vim-mark
========

A clone of http://www.vim.org/scripts/script.php?script_id=2666
